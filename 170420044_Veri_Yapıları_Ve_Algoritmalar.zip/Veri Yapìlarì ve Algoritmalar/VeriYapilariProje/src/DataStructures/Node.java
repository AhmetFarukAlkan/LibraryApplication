
package DataStructures;

import Classes.Borrowed;

public class Node 
{
    public Borrowed data;
    public Node next;       
}