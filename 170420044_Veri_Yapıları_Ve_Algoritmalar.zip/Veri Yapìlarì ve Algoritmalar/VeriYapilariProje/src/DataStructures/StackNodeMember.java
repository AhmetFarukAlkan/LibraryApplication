package DataStructures;

import Classes.Member;
import Classes.User;

public class StackNodeMember {
    
    Member member;
    StackNodeMember next;

}
