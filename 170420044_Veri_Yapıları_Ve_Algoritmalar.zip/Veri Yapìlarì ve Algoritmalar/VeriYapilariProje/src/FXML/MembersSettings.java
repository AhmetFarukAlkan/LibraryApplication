/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FXML;

import Classes.Admin;
import Classes.Datas;
import Classes.Member;
import Classes.User;
import DataStructures.HashTable01;
import DataStructures.SQL;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author dursun
 */
public class MembersSettings extends Application implements Initializable{
    SQL sql = new SQL();
    Datas datas = new Datas();    
    Admin admin = new Admin();
 
    public void setAdmin(Admin admin) {
        this.admin = admin;
    } 
    
    @FXML
    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("MembersSettingsFXML.fxml"));
        primaryStage.setScene(new Scene(root));
        primaryStage.show();    
    }
    
    @FXML
    private ImageView Exit;

    @FXML
    private Button btnSearch;

    @FXML
    private ImageView deleteMember;

    @FXML
    private ImageView listBooks;

    @FXML
    private DatePicker DataPickerBirthDate;

    @FXML
    private TextField txfldMail;

    @FXML
    private TextField txfldName;

    @FXML
    private TextField txfldNickname;

    @FXML
    private TextField txfldSearch;

    @FXML
    private TextField txfldSurname;

    @FXML
    private TextField txfldTelNum;

    @FXML
    private TableColumn<User, LocalDate> ColumnBirthDate;

    @FXML
    private TableColumn<User, String> ColumnMail;

    @FXML
    private TableColumn<User, String> ColumnName;

    @FXML
    private TableColumn<User, String> ColumnSurname;

    @FXML
    private TableColumn<User, String> ColumnTelNo;

    @FXML
    private TableColumn<User, Integer> Columnid;
    
    @FXML
    private TableView<User> TblVwUsers;
    
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        ColumnBirthDate.setCellValueFactory(new PropertyValueFactory<>("BirthDate"));
        ColumnMail.setCellValueFactory(new PropertyValueFactory<>("Mail"));
        ColumnName.setCellValueFactory(new PropertyValueFactory<>("Name"));;
        ColumnSurname.setCellValueFactory(new PropertyValueFactory<>("Surname"));;
        ColumnTelNo.setCellValueFactory(new PropertyValueFactory<>("TelNo"));;
        Columnid.setCellValueFactory(new PropertyValueFactory<>("id"));;
    }
    
    @FXML
    void ClickExit(MouseEvent event) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AdminMainFXML.fxml"));
        Parent root = loader.load();

        AdminMainScreen adminMainScreen = loader.getController();
        adminMainScreen.setAdminMainScreen(this.admin);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    void ClickDeleteMember(MouseEvent event) throws SQLException {
        User user = TblVwUsers.getSelectionModel().getSelectedItem();
        if(user != null){
            sql.deleteUser(user);
            datas.getUsers().deleteMember(datas.getUsers().search(user.getNickname()));
            txfldMail.setText("");
            txfldName.setText("");
            txfldNickname.setText("");
            txfldSurname.setText("");
            txfldTelNum.setText("");
            DataPickerBirthDate.setValue(null);
            ClickSearch(event);
        }
    }    

    
    @FXML
    void ClickTable(MouseEvent event) {
        User user = TblVwUsers.getSelectionModel().getSelectedItem();
        if(user != null){
            DataPickerBirthDate.setValue(user.getBirthDate());
            txfldMail.setText(user.getMail());
            txfldName.setText(user.getName());
            txfldNickname.setText(user.getNickname());
            txfldSurname.setText(user.getSurname());
            txfldTelNum.setText(user.getTelNo());
        }
    }
    
    @FXML
    void ClickSearch(MouseEvent event) {
        TblVwUsers.getItems().clear();
        users = TblVwUsers.getItems();
        writeUsers();
        TblVwUsers.setItems(users);
    }
    
    ObservableList<User> users;
    
    public void writeUsers(){
        HashTable01<Member> useHashTable01 = datas.getUsers();
        boolean next = true;
        int i = 0;
        while(next){
            if(useHashTable01.get(i)!=null && useHashTable01.get(i) instanceof User){
                users.add((User)useHashTable01.get(i));                
            }
            i++;
            if(i>2000){
                next = false;
            }
        }
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
