/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package FXML;

import Classes.Admin;
import Classes.Book;
import Classes.Datas;
import DataStructures.BST;
import DataStructures.SQL;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 *
 * @author dursun
 */
public class ShowBooks extends Application implements Initializable{
    
    SQL sql = new SQL();
    Datas datas = new Datas();
    Admin admin = new Admin();
    
    @FXML
    public void setAdmin(Admin admin) {
        this.admin = admin;
    } 
    
    @Override
    public void start(Stage primaryStage) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ShowBooksFXML.fxml"));
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

     @FXML
    private TableColumn<Book, String> ColumnAuthor;

    @FXML
    private TableColumn<Book, String> ColumnBookName;

    @FXML
    private TableColumn<Book, Integer> ColumnId;

    @FXML
    private TableColumn<Book, Integer> ColumnPageNumber;

    @FXML
    private TableColumn<Book, Integer> ColumnPiece;

    @FXML
    private TableColumn<Book, String> ColumnPublisher;

    @FXML
    private TableColumn<Book, String> ColumnYearOfPublication;
    
    @FXML
    private Button BtnSrch;

    @FXML
    private ImageView Exit;

    @FXML
    private TableView<Book> TblVwBooks;

    @FXML
    private ImageView deleteBook;

    @FXML
    private TextField txfldBookName;

    @FXML
    private DatePicker DtPicekrPublish;

    @FXML
    private TextField txfldAvailablePiece;
    
    @FXML
    private TextField txfldNumber;

    @FXML
    private TextField txfldPageNumber;

    @FXML
    private TextField txfldPublisher;

    @FXML
    private TextField txfldSearch;

    @FXML
    private TextField txfldWriter;

    @FXML
    private ImageView updateBook;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        ColumnAuthor.setCellValueFactory(new PropertyValueFactory<>("author"));
        ColumnBookName.setCellValueFactory(new PropertyValueFactory<>("BookName"));
        ColumnId.setCellValueFactory(new PropertyValueFactory<>("id"));;
        ColumnPageNumber.setCellValueFactory(new PropertyValueFactory<>("NumberPage"));;
        ColumnPiece.setCellValueFactory(new PropertyValueFactory<>("piece"));;
        ColumnPublisher.setCellValueFactory(new PropertyValueFactory<>("Publisher"));;
        ColumnYearOfPublication.setCellValueFactory(new PropertyValueFactory<>("YearOfPublication"));;
    }
    
    ObservableList<Book> books ;
    @FXML
    void ClickBtnSearch(MouseEvent event) {
        books= TblVwBooks.getItems();
        TblVwBooks.getItems().clear();
        inorder();
        TblVwBooks.setItems(books);
    }
    
    public void inorder() { 
        inorder_Recursive(datas.getBooks().root); 
    } 
   
    public void inorder_Recursive(BST.Node root) { 
        if (root != null) { 
            inorder_Recursive(root.left); 
            books.add(root.key);
            inorder_Recursive(root.right); 
        } 
    }
    
    @FXML
    void ClickDeleteBook(MouseEvent event) throws SQLException {
        Book book = TblVwBooks.getSelectionModel().getSelectedItem();
        if(book != null){
            sql.deleteBook(book);
            datas.setBooks();
            txfldAvailablePiece.setText("");
            txfldBookName.setText("");
            txfldNumber.setText("");
            txfldNumber.setText("");
            txfldPageNumber.setText("");
            txfldPublisher.setText("");
            txfldSearch.setText("");
            txfldWriter.setText("");
            DtPicekrPublish.setValue(null);
            ClickBtnSearch(event);
            
        }
    }

    @FXML
    void ClickExit(MouseEvent event) throws IOException, Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AdminMainFXML.fxml"));
        Parent root = loader.load();

        AdminMainScreen adminMainScreen = loader.getController();
        adminMainScreen.setAdminMainScreen(this.admin);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    
    @FXML
    void ClickTable(MouseEvent event) {
        Book book = TblVwBooks.getSelectionModel().getSelectedItem();
        if(book != null){
            txfldBookName.setText(book.getBookName());
            txfldWriter.setText(book.getAuthor());
            txfldPageNumber.setText(String.valueOf(book.getNumberPage()));
            DtPicekrPublish.setValue(book.getYearOfPublication());
            txfldPublisher.setText(book.getPublisher());
            txfldNumber.setText(String.valueOf(book.getPiece()));
            txfldAvailablePiece.setText(String.valueOf(book.getAvailablePiece()));            
        }    
    }
    
    @FXML
    void ClickUpdateBook(MouseEvent event) throws SQLException {
        if(!txfldAvailablePiece.getText().equals("") && !txfldBookName.getText().equals("") && DtPicekrPublish.getValue() != null  && !txfldNumber.getText().equals("") && !txfldPageNumber.getText().equals("") && !txfldPublisher.getText().equals("") && !txfldWriter.getText().equals("")){
            Book book = TblVwBooks.getSelectionModel().getSelectedItem();
            if(book != null){
                book.setAuthor(txfldWriter.getText());
                book.setAvailablePiece(Integer.valueOf(txfldAvailablePiece.getText()));
                book.setBookName(txfldBookName.getText());
                book.setNumberPage(Integer.valueOf(txfldPageNumber.getText()));
                book.setPiece(Integer.valueOf(txfldNumber.getText()));
                book.setPublisher(txfldPublisher.getText());
                book.setYearOfPublication(DtPicekrPublish.getValue());
                sql.UpdateBookİnfo(book);
                Alert alert = new Alert(Alert.AlertType.INFORMATION,"Kitap bilgileri güncellendi.",ButtonType.CANCEL);
                alert.showAndWait();
                ClickBtnSearch(event);
            }
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR,"Tüm alanları doldurunuz.",ButtonType.CANCEL);
            alert.showAndWait();
        }

    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
