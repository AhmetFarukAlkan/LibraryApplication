/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FXML;

import Classes.User;
import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 *
 * @author dursun
 */
public class MemberMainScreen extends Application{
    
    User user ;
     
    @Override
    public void start(Stage primaryStage) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("MemberMainFXML.fxml"));
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    @FXML
    private ImageView Exit;

    @FXML
    private ImageView MemberSettings;

    @FXML
    private ImageView ShowBooks;

    @FXML
    private ImageView giveBook;

    @FXML
    private ImageView takeBook;
    
    @FXML
    public Label LblWelcome;
    
    @FXML
    void setMemberMainScreen(User user) {
        this.user = user;
        LblWelcome.setText("Hoşgeldiniz "+user.getNickname());    
    }
    
    @FXML
    void ClickExit(MouseEvent event) throws Exception {
        Parent tableMmbrScreen = FXMLLoader.load(getClass().getResource("FXML.fxml"));
        Scene tableLoginScene = new Scene(tableMmbrScreen);
     
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        Login LoginScreen = new Login();
        LoginScreen.start(window);
        window.show();
    }

    @FXML
    void ClickGiveBook(MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("GiveBookFXML.fxml"));
        Parent root = loader.load();

        GiveBook giveBook = loader.getController();
        giveBook.setUser(user);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void ClickMemberSettings(MouseEvent event) throws IOException, Exception {
        
        FXMLLoader loader = new FXMLLoader(getClass().getResource("PersonalInfosFXML.fxml"));
        Parent root = loader.load();

        PersonalInfos personalInfos= loader.getController();
        personalInfos.setPersonalInfos(user);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void ClickShowBooks(MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("BooksInfoFXML.fxml"));
        Parent root = loader.load();

        BooksInfo booksInfo= loader.getController();
        booksInfo.setUser(user);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void ClickTakeBook(MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("TakeBookFXML.fxml"));
        Parent root = loader.load();

        TakeBook takeBook= loader.getController();
        takeBook.setUser(user);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
