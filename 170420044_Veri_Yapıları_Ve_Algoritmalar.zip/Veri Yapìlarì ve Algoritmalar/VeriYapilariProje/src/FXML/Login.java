package FXML;

import Classes.Admin;
import Classes.Datas;
import Classes.User;
import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class Login extends Application{
    
    Datas datas = new Datas();
    
    @FXML
    private Button BtnRegister;

    @FXML
    private Button BtnSingin;

    @FXML
    private PasswordField pasword;

    @FXML
    private TextField txtfldNick;
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXML.fxml"));
        primaryStage.setScene(new Scene(root));
        datas.addUser(datas.admin);
        datas.addUser(datas.user);
        primaryStage.show();
    }
    
    @FXML
    void ClickBtnRegister(MouseEvent event) throws IOException {
        Parent tableRegisterScreen = FXMLLoader.load(getClass().getResource("RegisterFXML.fxml"));
        Scene tableRegisterScene = new Scene(tableRegisterScreen);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        Register register = new Register();
        register.start(window);
        window.show();
    }

    @FXML
    void ClickSingin(MouseEvent event) throws IOException {
        try{
            if(datas.getUsers().get(datas.getUsers().search(txtfldNick.getText())).getNickname().equals(txtfldNick.getText()) && datas.getUsers().get(datas.getUsers().search(txtfldNick.getText())).getPassword().equals(pasword.getText())){
                if(datas.getUsers().get(datas.getUsers().search(txtfldNick.getText())) instanceof Admin){
                    String nick = txtfldNick.getText();
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("AdminMainFXML.fxml"));
                    Parent root = loader.load();
                    
                    AdminMainScreen adminMainScreen = loader.getController();
                    adminMainScreen.setAdminMainScreen((Admin) datas.getUsers().get(datas.getUsers().search(txtfldNick.getText())));
                    
                    Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                }else{
                    String nick = txtfldNick.getText();
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("MemberMainFXML.fxml"));
                    Parent root = loader.load();
                    
                    MemberMainScreen memberMainScreen = loader.getController();
                    memberMainScreen.setMemberMainScreen((User) datas.getUsers().get(datas.getUsers().search(txtfldNick.getText())));
                    
                    Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                }
            }
            else{
                Alert alert = new Alert(Alert.AlertType.ERROR,"Kullanıcı adını veya şifreyi yanlış girdiniz",ButtonType.CANCEL);
                alert.showAndWait();
            }
            
            
        }catch(java.lang.RuntimeException e){
            Alert alert = new Alert(Alert.AlertType.ERROR,"Kullanıcı adını veya şifreyi yanlış girdiniz",ButtonType.CANCEL);
            alert.showAndWait();
        }
        
        
    }
    
    public static void main(String[] args) {
        launch(args);
    }
    
}
