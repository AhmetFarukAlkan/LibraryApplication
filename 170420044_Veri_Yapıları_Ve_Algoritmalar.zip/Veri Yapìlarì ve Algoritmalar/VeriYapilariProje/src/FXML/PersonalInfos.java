/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FXML;

import Classes.User;
import DataStructures.SQL;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Month;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 *
 * @author dursun
 */
public class PersonalInfos extends Application{

    SQL sql = new SQL();
    User user = new User();

    @FXML
    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("PersonalInfosFXML.fxml"));
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    @FXML
    private DatePicker BirthDate;

    @FXML
    private ImageView Exit;

    @FXML
    private ImageView Upgrade;

    @FXML
    private TextField txtfldMail;

    @FXML
    private TextField txtfldName;

    @FXML
    private TextField txtfldNick;

    @FXML
    private PasswordField txtfldPswrd1;

    @FXML
    private PasswordField txtfldPswrd2;

    @FXML
    private TextField txtfldSurname;

    @FXML
    private TextField txtfldTelNo;
    
    @FXML
    void ClickUpgrade(MouseEvent event) throws SQLException {
        if(txtfldPswrd1.getText().equals(txtfldPswrd2.getText()) && !txtfldPswrd1.getText().equals("")){
            user.setPassword(txtfldPswrd1.getText());
        }else if(!txtfldPswrd1.getText().equals("")){
            Alert alert = new Alert(Alert.AlertType.ERROR,"Girilen iki şifre farklı.",ButtonType.CANCEL);
            alert.showAndWait();
        }    
        user.setMail(txtfldMail.getText());
        user.setTelNo(txtfldTelNo.getText());
        sql.UpdateUserİnfo(user);
        Alert alert = new Alert(Alert.AlertType.INFORMATION,"Bilgileriniz başarıyla güncellendi.",ButtonType.CANCEL);
        alert.showAndWait();
        
    }
    
    @FXML
    void setPersonalInfos(User user) {
        this.user = user;
        txtfldNick.setText(user.getNickname());
        txtfldMail.setText(user.getMail());
        txtfldName.setText(user.getName());
        txtfldSurname.setText(user.getSurname());
        txtfldTelNo.setText(user.getTelNo());
        BirthDate.setValue(this.user.getBirthDate());
    }
    
    @FXML
    void ClickExit(MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("MemberMainFXML.fxml"));
        Parent root = loader.load();

        MemberMainScreen memberMainScreen= loader.getController();
        memberMainScreen.setMemberMainScreen(user);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();         
    }
    
    public static void main(String[] args) {
        launch(args); 
    }
}
