/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package FXML;

import Classes.Datas;
import Classes.Member;
import Classes.User;
import DataStructures.SQL;
import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 *
 * @author dursun
 */
public class Register extends Application {
    
    SQL sql = new SQL();  
    Datas datas = new Datas();
    
    @FXML
    private DatePicker BirthDate;

    @FXML
    private Button BtnExit;

    @FXML
    private Button BtnRegister;

    @FXML
    private TextField txtfldMail;

    @FXML
    private TextField txtfldName;

    @FXML
    private TextField txtfldNick;

    @FXML
    private PasswordField txtfldPswrd1;

    @FXML
    private PasswordField txtfldPswrd2;

    @FXML
    private TextField txtfldSurname;

    @FXML
    private TextField txtfldTelNo;

    @FXML
    void ClickExit(MouseEvent event) throws Exception {
        Parent tableMmbrScreen = FXMLLoader.load(getClass().getResource("FXML.fxml"));
        Scene tableLoginScene = new Scene(tableMmbrScreen);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        Login LoginScreen = new Login();
        LoginScreen.start(window);
        window.show();
    }

    @FXML
    void ClickRegister(MouseEvent event) throws Exception {
        if(!txtfldMail.getText().equals("")&&!txtfldName.getText().equals("")&&!txtfldNick.getText().equals("")&&!txtfldPswrd1.getText().equals("")&&!txtfldPswrd2.getText().equals("")&&!txtfldSurname.getText().equals("")&&!txtfldTelNo.getText().equals("")&& BirthDate.valueProperty().getValue()!=null){
            if(txtfldPswrd1.getText().equals(txtfldPswrd2.getText())){
                if(datas.getUsers().search(txtfldNick.getText()) == -1){
                    User user =new User(txtfldNick.getText(), txtfldPswrd1.getText(), txtfldName.getText(), txtfldSurname.getText(), txtfldMail.getText(), txtfldTelNo.getText(), BirthDate.getValue());                    
                    sql.saveUser(user);
                    user.setİdFromSQL();
                    datas.addUser(user);
                    Parent tableMmbrScreen = FXMLLoader.load(getClass().getResource("FXML.fxml"));
                    Scene tableLoginScene = new Scene(tableMmbrScreen);
                    Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
                    Login LoginScreen = new Login();
                    LoginScreen.start(window);
                    window.show();
                }
                else{
                    Alert alert = new Alert(Alert.AlertType.ERROR,"Girilen kullanıcı adı daha önce başkası tarafından alınmış.",ButtonType.CANCEL);
                    alert.showAndWait();
                }
            }
            else{
                Alert alert = new Alert(Alert.AlertType.ERROR,"Girilen iki şifre farklı.",ButtonType.CANCEL);
                alert.showAndWait();  
            }
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR,"Tüm alanları doldurunuz.",ButtonType.CANCEL);
            alert.showAndWait();
        }

    }
    
    @FXML
    @Override
    public void start(Stage primaryStage) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("RegisterFXML.fxml"));
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
