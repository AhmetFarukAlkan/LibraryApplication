/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package FXML;

import Classes.Book;
import Classes.Borrowed;
import Classes.Datas;
import Classes.User;
import DataStructures.BST;
import DataStructures.SQL;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 *
 * @author dursun
 */
public class TakeBook extends Application implements Initializable{
    
    SQL sql= new SQL();
    Datas datas = new Datas();
    User user = new User();
    
    @Override
    public void start(Stage primaryStage) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("TakeBookFXML.fxml"));
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }
    @FXML
    private Button BtnSrch;

    @FXML
    private ImageView Exit;

    @FXML
    private Rectangle Takeit;

    @FXML
    private TableView<Book> TblVwBooks;

    @FXML
    private TextField txfldSearch;

    @FXML
    private TableColumn<Book, String> columnAuthor;

    @FXML
    private TableColumn<Book, String> columnBookName;

    @FXML
    private TableColumn<Book, Integer> columnId;

    @FXML
    private TableColumn<Book, Integer> columnPageNumber;

    @FXML
    private TableColumn<Book, Integer> columnPiece;

    @FXML
    private TableColumn<Book, String> columnPublisher;

    @FXML
    private TableColumn<Book, LocalDate> columnPublisherDate;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        columnAuthor.setCellValueFactory(new PropertyValueFactory<>("author"));
        columnBookName.setCellValueFactory(new PropertyValueFactory<>("BookName"));
        columnId.setCellValueFactory(new PropertyValueFactory<>("id"));;
        columnPageNumber.setCellValueFactory(new PropertyValueFactory<>("NumberPage"));;
        columnPiece.setCellValueFactory(new PropertyValueFactory<>("availablePiece"));;
        columnPublisher.setCellValueFactory(new PropertyValueFactory<>("Publisher"));;
        columnPublisherDate.setCellValueFactory(new PropertyValueFactory<>("YearOfPublication"));;
    }
    
    ObservableList<Book> books;
    @FXML
    void ClickBtnSearch(MouseEvent event) {
        books= TblVwBooks.getItems();
        TblVwBooks.getItems().clear();
        inorder();
        TblVwBooks.setItems(books);
    }

    public void inorder() { 
        inorder_Recursive(datas.getBooks().root); 
    } 
   
    public void inorder_Recursive(BST.Node root) { 
        if (root != null) { 
            inorder_Recursive(root.left); 
            books.add(root.key);
            inorder_Recursive(root.right); 
        } 
    }
    
    @FXML
    void setUser(User user) {
        this.user = user;
    }
    
    @FXML
    void ClickExit(MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("MemberMainFXML.fxml"));
        Parent root = loader.load();

        MemberMainScreen memberMainScreen= loader.getController();
        memberMainScreen.setMemberMainScreen(user);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();          
    }

    @FXML
    void ClickTakeit(MouseEvent event) throws SQLException {
        Book book = TblVwBooks.getSelectionModel().getSelectedItem();
        if(book != null){
            if(book.getAvailablePiece()>0){
                book.setAvailablePiece(book.getAvailablePiece()-1);   
                sql.UpdateBookİnfo(book);
                user.addBook(bookToBorrowedBook(book));
                sql.saveBorrowedBook(bookToBorrowedBook(book));
                ClickBtnSearch(event);
                Alert alert = new Alert(Alert.AlertType.INFORMATION,"Kitap ödünç alındı.",ButtonType.CANCEL);
                alert.showAndWait();
            }
            else{
                Alert alert = new Alert(Alert.AlertType.ERROR,"Seçilen kitap kütüphanede yeterince yok.",ButtonType.CANCEL);
                alert.showAndWait();
            }
           
        }
    }
    
    public Borrowed bookToBorrowedBook(Book book){
        Borrowed borrowed = new Borrowed();
        
        borrowed.setAuthor(book.getAuthor());
        borrowed.setBookName(book.getBookName());
        borrowed.setMemberName(user.getNickname());
        borrowed.setNumberPage(book.getNumberPage());
        borrowed.setPublisher(book.getPublisher());
        borrowed.setStatus("Ödünç Alınmış");
        borrowed.setYearOfPublication(book.getYearOfPublication());
        borrowed.setMainBook(book);
        return borrowed;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    
    
}
